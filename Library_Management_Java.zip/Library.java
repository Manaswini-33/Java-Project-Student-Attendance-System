
import java.util.*;

class Book {
    String title;
    boolean issued;

    Book(String title) {
        this.title = title;
        this.issued = false;
    }
}

public class Library {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Book> books = new ArrayList<>();

        while (true) {
            System.out.println("\n1. Add Book  2. Issue Book  3. Show Books  4. Exit");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter book name: ");
                    books.add(new Book(sc.nextLine()));
                    break;

                case 2:
                    System.out.print("Enter book name to issue: ");
                    String name = sc.nextLine();
                    for (Book b : books) {
                        if (b.title.equalsIgnoreCase(name) && !b.issued) {
                            b.issued = true;
                            System.out.println("Book Issued!");
                        }
                    }
                    break;

                case 3:
                    for (Book b : books) {
                        System.out.println(b.title + " - " + (b.issued ? "Issued" : "Available"));
                    }
                    break;

                case 4:
                    System.exit(0);
            }
        }
    }
}
