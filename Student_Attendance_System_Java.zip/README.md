
# Student Attendance System (Java)

## Description
A console-based Java mini project to manage and track student attendance.

## Features
- Add student details
- Mark attendance (Present/Absent)
- View attendance report
- Menu-driven system

## Technologies Used
- Java
- Collections (ArrayList)
- Scanner class

## How to Run
javac AttendanceSystem.java
java AttendanceSystem
