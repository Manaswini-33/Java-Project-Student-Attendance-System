
import java.util.*;

class Student {
    int id;
    String name;
    boolean present;

    Student(int id, String name) {
        this.id = id;
        this.name = name;
        this.present = false;
    }
}

public class AttendanceSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        while (true) {
            System.out.println("\n--- Student Attendance System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Mark Attendance");
            System.out.println("3. View Attendance");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Student Name: ");
                    String name = sc.nextLine();
                    students.add(new Student(id, name));
                    System.out.println("Student Added Successfully!");
                    break;

                case 2:
                    System.out.print("Enter Student ID to mark present: ");
                    int searchId = sc.nextInt();
                    boolean found = false;
                    for (Student s : students) {
                        if (s.id == searchId) {
                            s.present = true;
                            found = true;
                            System.out.println("Attendance Marked Present");
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student Not Found");
                    }
                    break;

                case 3:
                    System.out.println("\n--- Attendance Report ---");
                    for (Student s : students) {
                        System.out.println("ID: " + s.id + 
                                           ", Name: " + s.name + 
                                           ", Status: " + (s.present ? "Present" : "Absent"));
                    }
                    break;

                case 4:
                    System.out.println("Exiting System...");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }
}
